import os
from datetime import datetime
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

class ReportGenerator:
    def __init__(self):
        self.records_folder = f"{os.getcwd()}\\records"
        self.reports_folder = f"{os.getcwd()}\\reports"

    def create_report(self, date):
        # Create the "reports" folder if it doesn't exist
        os.makedirs(self.reports_folder, exist_ok=True)

        # Get the list of URLs from the records folder
        urls = os.listdir(self.records_folder)

        # Sort the URLs alphabetically
        urls.sort()

        # Create a PDF report file
        report_filename = os.path.join(self.reports_folder, f"Records_{date}.pdf")
        pdf = canvas.Canvas(report_filename, pagesize=letter)
        pdf.setFont("Helvetica-Bold", 18)
        pdf.setTitle(f"Records - {date}")

        y = 720  # Initial y-coordinate

        # Set report title and subtitle
        pdf.drawString(50, y, f"Records - {date}")
        pdf.setFont("Helvetica", 14)
        pdf.drawString(50, y - 30, "Summary of Records")

        # Add creation time at the top right
        creation_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        pdf.setFont("Helvetica", 10)
        pdf.drawRightString(550, y, f"Created on: {creation_time}")

        y -= 70  # Move down

        # Flag to track if any records were found
        records_found = False

        # Iterate over URLs and their records
        for url in urls:
            url_folder = os.path.join(self.records_folder, url)

            # Check if the URL folder exists
            if not os.path.isdir(url_folder):
                continue

            date_folder_path = os.path.join(url_folder, date)

            # Check if the date folder exists
            if not os.path.isdir(date_folder_path):
                continue

            # Get the list of record files for the URL and date
            record_files = os.listdir(date_folder_path)
            record_files.sort()

            # URL header
            pdf.setFont("Helvetica-Bold", 12)
            pdf.drawString(50, y, f"URL: {url}")
            y -= 20  # Move down

            # Records list
            pdf.setFont("Helvetica", 10)
            for record_file in record_files:
                file_name = record_file.split('_')[1]  # Extract the filename from the log file name
                file_path = os.path.join(date_folder_path, record_file)
                file_size = os.path.getsize(file_path)
                file_size_str = f"{file_size / 1024:.2f} KB"  # Convert size to KB and format as string
                pdf.drawString(70, y, f"{file_name} - {file_size_str}")
                y -= 15  # Move down

            # Add the count of log files (bold)
            total_records = len(record_files)
            pdf.setFont("Helvetica-Bold", 10)
            pdf.drawString(70, y, f"Total Records: {total_records}")
            y -= 15  # Move down

            y -= 10  # Add extra spacing between URLs

            # Records found for at least one URL
            records_found = True

        # Add some color and styling to the PDF report
        pdf.setFillColorRGB(0.2, 0.4, 0.6)  # Set fill color to blue
        pdf.rect(40, 710, 510, 1, fill=True, stroke=False)  # blue rectangle as a separator line
        pdf.rect(40, 675, 510, 1, fill=True, stroke=False)
        pdf.setFillColorRGB(0, 0, 0)  # Reset fill color to black

        # If no records were found for any URL
        if not records_found:
            pdf.setFont("Helvetica", 10)
            pdf.drawString(50, y, f"No records were recorded on {date}")
            y -= 15

        # Save and close the PDF file
        pdf.save()

        print(f"Report file created: Records_{date}.pdf")
