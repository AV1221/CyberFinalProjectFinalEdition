from flask import Flask, request
from keyStrokeRecorder import KeyStrokeRecorder
from UrlValidation import URLChecker


class UrlCatch:
    def __init__(self):
        self.app = Flask(__name__)

        @self.app.route('/urls', methods=['POST'])
        def receive_urls():
            url = request.json['urls']
            if len(url) > 0:
                url_checker = URLChecker()
                id = url_checker.check_exists(url)
                if id >= 0:
                    capture = KeyStrokeRecorder(id)
                    #capture.start()
                return 'OK'

    def run(self):
        self.app.run()


if __name__ == '__main__':
    urlCatcher = UrlCatch()
    urlCatcher.run()
