import json


def returnData():
    with open("Config.json", "r") as jsonfile:
        data = json.load(jsonfile)  # Reading the file
        jsonfile.close()
        return data
